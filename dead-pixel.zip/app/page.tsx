import { Experience } from '@/components/experience'

export default function Page() {
  return (
    <main>
      <Experience />
    </main>
  )
}
