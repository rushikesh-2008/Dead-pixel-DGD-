'use client'

import { useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { Screen } from '@/components/crt-frame'
import { GlitchText } from '@/components/glitch-text'
import { pixelsToDataURL } from '@/lib/pixel-utils'

export function NameScreen() {
  const { advance, setName, name, savedPixels } = useExperience()
  const [value, setValue] = useState(name)
  const preview = pixelsToDataURL(savedPixels, 3)

  const submit = () => {
    const trimmed = value.trim().slice(0, 18)
    setName(trimmed || 'PIXEL')
    advance()
  }

  return (
    <Screen>
      <GlitchText style={{ fontSize: 'clamp(1.3rem, 4vw, 2.4rem)' }}>
        GIVE IT A NAME.
      </GlitchText>

      <img
        src={preview || '/placeholder.svg'}
        alt="Your cursor"
        width={64}
        height={64}
        style={{
          imageRendering: 'pixelated',
          border: '1px solid var(--dp-line)',
          background: '#0a1014',
          padding: 6,
        }}
      />

      <input
        autoFocus
        value={value}
        maxLength={18}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) {
            submit()
          }
        }}
        placeholder="TYPE A NAME"
        aria-label="Cursor name"
        className="font-pixel"
        style={{
          fontSize: '0.9rem',
          textAlign: 'center',
          textTransform: 'uppercase',
          color: 'var(--dp-green)',
          background: 'transparent',
          border: 'none',
          borderBottom: '2px solid var(--dp-green)',
          padding: '10px 6px',
          outline: 'none',
          width: 'min(360px, 80vw)',
          caretColor: 'var(--dp-green)',
        }}
      />

      <button type="button" className="dp-btn" onClick={submit}>
        Save
      </button>
    </Screen>
  )
}
