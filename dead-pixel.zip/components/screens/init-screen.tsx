'use client'

import { useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { Screen } from '@/components/crt-frame'
import { TerminalLines } from '@/components/terminal-lines'

const LINES = [
  'INITIALIZING CURSOR BUILDER…',
  'MOUSE DETECTED.',
  "LET'S MAKE SOMETHING THAT LOOKS LIKE YOU.",
]

export function InitScreen() {
  const { advance } = useExperience()
  const [done, setDone] = useState(false)
  return (
    <Screen>
      <TerminalLines lines={LINES} onDone={() => setDone(true)} />
      <button
        type="button"
        className="dp-btn"
        onClick={advance}
        disabled={!done}
        style={{ opacity: done ? 1 : 0.3 }}
      >
        Continue
      </button>
    </Screen>
  )
}
