'use client'

/**
 * Stage 5 — Cursor Test Room. Three ordinary tasks (move, click, drag) that all
 * work normally. Completing them shows TEST COMPLETE. This is the calm before
 * everything starts to go wrong.
 */

import { useEffect, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import {
  inside,
  useVirtualClick,
  useVirtualFrame,
} from '@/components/use-virtual-pointer'

type Step = 'move' | 'click' | 'drag' | 'complete'

const PROMPTS: Record<Step, string> = {
  move: 'MOVE THE CURSOR ONTO THE TARGET.',
  click: 'CLICK THE TARGET.',
  drag: 'DRAG THE BLOCK INTO THE BOX.',
  complete: 'TEST COMPLETE',
}

export function TestScreen() {
  const { advance, savedPixels } = useExperience()
  const [step, setStep] = useState<Step>('move')
  const [dwell, setDwell] = useState(0)

  const moveRef = useRef<HTMLDivElement>(null)
  const clickRef = useRef<HTMLButtonElement>(null)
  const boxRef = useRef<HTMLDivElement>(null)
  const objRef = useRef<HTMLDivElement>(null)
  const draggingRef = useRef(false)
  const objPos = useRef({ x: 0, y: 0 })
  const dwellRef = useRef(0)

  // Position the draggable block once mounted.
  useEffect(() => {
    objPos.current = {
      x: window.innerWidth * 0.32,
      y: window.innerHeight * 0.62,
    }
    if (objRef.current) {
      objRef.current.style.left = `${objPos.current.x}px`
      objRef.current.style.top = `${objPos.current.y}px`
    }
  }, [])

  // Task 1 — dwell on the target.
  useVirtualFrame((x, y, dt) => {
    const el = moveRef.current
    if (!el) return
    if (inside(x, y, el.getBoundingClientRect())) {
      dwellRef.current += dt
      setDwell(Math.min(1, dwellRef.current / 0.5))
      if (dwellRef.current >= 0.5) setStep('click')
    } else {
      dwellRef.current = 0
      setDwell(0)
    }
  }, step === 'move')

  // Task 2 — click the target.
  useVirtualClick((x, y) => {
    const el = clickRef.current
    if (el && inside(x, y, el.getBoundingClientRect())) setStep('drag')
  }, step === 'click')

  // Task 3 — drag the block into the box.
  useVirtualClick((x, y) => {
    const el = objRef.current
    if (el && inside(x, y, el.getBoundingClientRect())) draggingRef.current = true
  }, step === 'drag')

  useEffect(() => {
    if (step !== 'drag') return
    const up = () => {
      draggingRef.current = false
      const box = boxRef.current
      const obj = objRef.current
      if (box && obj) {
        const b = box.getBoundingClientRect()
        const o = obj.getBoundingClientRect()
        const cx = o.left + o.width / 2
        const cy = o.top + o.height / 2
        if (inside(cx, cy, b)) setStep('complete')
      }
    }
    window.addEventListener('pointerup', up)
    return () => window.removeEventListener('pointerup', up)
  }, [step])

  useVirtualFrame((x, y) => {
    if (!draggingRef.current || !objRef.current) return
    objPos.current = { x, y }
    objRef.current.style.left = `${x}px`
    objRef.current.style.top = `${y}px`
  }, step === 'drag')

  return (
    <>
      <CursorEngine pixels={savedPixels} active />

      <div
        className="dp-fade-in"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          textAlign: 'center',
          paddingTop: '4rem',
          zIndex: 5,
        }}
      >
        <GlitchText as="h2" glitch={false} style={{ fontSize: '0.9rem' }}>
          {step === 'complete' ? 'TEST COMPLETE' : 'CURSOR TEST ROOM'}
        </GlitchText>
        <p
          className="font-terminal"
          style={{ color: 'var(--dp-green-dim)', fontSize: '1.2rem', marginTop: 8 }}
        >
          {PROMPTS[step]}
        </p>
      </div>

      {/* Task 1 target */}
      {step === 'move' && (
        <div
          ref={moveRef}
          style={{
            position: 'fixed',
            left: '50%',
            top: '45%',
            width: 90,
            height: 90,
            transform: 'translate(-50%, -50%)',
            borderRadius: '50%',
            border: '2px solid var(--dp-green)',
            display: 'grid',
            placeItems: 'center',
            boxShadow: `0 0 ${8 + dwell * 20}px rgba(53,255,124,${0.3 + dwell * 0.5})`,
          }}
        >
          <div
            style={{
              width: 20 + dwell * 40,
              height: 20 + dwell * 40,
              borderRadius: '50%',
              background: 'var(--dp-green)',
              opacity: 0.4 + dwell * 0.6,
            }}
          />
        </div>
      )}

      {/* Task 2 target */}
      {step === 'click' && (
        <button
          ref={clickRef}
          type="button"
          className="dp-btn"
          style={{
            position: 'fixed',
            left: '50%',
            top: '45%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          Click Me
        </button>
      )}

      {/* Task 3 drag */}
      {step === 'drag' && (
        <>
          <div
            ref={boxRef}
            style={{
              position: 'fixed',
              right: '18%',
              top: '55%',
              width: 130,
              height: 130,
              transform: 'translateY(-50%)',
              border: '2px dashed var(--dp-cyan)',
              display: 'grid',
              placeItems: 'center',
              color: 'var(--dp-cyan)',
              fontSize: '0.9rem',
            }}
            className="font-terminal"
          >
            DROP HERE
          </div>
          <div
            ref={objRef}
            style={{
              position: 'fixed',
              width: 56,
              height: 56,
              transform: 'translate(-50%, -50%)',
              background: 'var(--dp-green)',
              boxShadow: '0 0 16px rgba(53,255,124,0.5)',
            }}
          />
        </>
      )}

      {step === 'complete' && (
        <button
          type="button"
          className="dp-btn"
          onClick={advance}
          style={{
            position: 'fixed',
            left: '50%',
            top: '60%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          Continue
        </button>
      )}
    </>
  )
}
