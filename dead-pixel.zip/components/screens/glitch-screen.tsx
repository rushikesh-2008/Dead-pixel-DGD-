'use client'

/**
 * Stage 6 — First Glitch. One pixel of the design silently changes and the
 * cursor begins to twitch. Message: "THAT'S ODD." Kept deliberately subtle.
 */

import { useEffect, useMemo, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { nudgeOnePixel } from '@/lib/pixel-utils'

export function GlitchScreen() {
  const { advance, savedPixels, setPixels } = useExperience()
  const [show, setShow] = useState(false)

  // The design is silently altered by a single pixel.
  const pixels = useMemo(() => nudgeOnePixel(savedPixels), [savedPixels])

  useEffect(() => {
    setPixels(pixels)
    const t = setTimeout(() => setShow(true), 1600)
    return () => clearTimeout(t)
  }, [pixels, setPixels])

  return (
    <>
      <CursorEngine
        pixels={pixels}
        active
        behavior={{ drift: 1.6, ignoreChance: 0.12 }}
      />
      <div
        style={{
          position: 'fixed',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '2rem',
          zIndex: 5,
        }}
      >
        <GlitchText
          style={{
            fontSize: 'clamp(1.2rem, 4vw, 2.2rem)',
            opacity: show ? 1 : 0,
            transition: 'opacity 0.8s ease',
          }}
        >
          {"THAT'S ODD."}
        </GlitchText>
        {show && (
          <button type="button" className="dp-btn dp-fade-in" onClick={advance}>
            Ignore It
          </button>
        )}
      </div>
    </>
  )
}
