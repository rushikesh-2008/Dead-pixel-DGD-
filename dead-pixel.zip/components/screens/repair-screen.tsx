'use client'

/**
 * Stage 12 — Repair Sequence. Back to the editor with the player's ORIGINAL
 * design, now missing / corrupted pixels. The pristine design is shown as a
 * faint ghost to restore toward. DONE unlocks once the grid matches exactly.
 */

import { useMemo, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { Screen } from '@/components/crt-frame'
import { GlitchText } from '@/components/glitch-text'
import { PixelEditor } from '@/components/pixel-editor'
import { corrupt, diffCount } from '@/lib/pixel-utils'

export function RepairScreen() {
  const { advance, savedPixels, setPixels, setCorruption } = useExperience()
  const damaged = useMemo(() => corrupt(savedPixels, 0.5, 99), [savedPixels])
  const [draft, setDraft] = useState<string[]>(damaged)

  const remaining = diffCount(draft, savedPixels)
  const fixed = remaining === 0

  const done = () => {
    if (!fixed) return
    setPixels(savedPixels)
    setCorruption(0)
    advance()
  }

  return (
    <Screen>
      <GlitchText as="h2" style={{ fontSize: 'clamp(1rem, 3vw, 1.6rem)' }}>
        YOUR CURSOR IS DAMAGED. REPAIR IT.
      </GlitchText>
      <p
        className="font-terminal"
        style={{ color: 'var(--dp-green-dim)', margin: 0, fontSize: '1.1rem' }}
      >
        match the faint outline.{' '}
        <span style={{ color: fixed ? 'var(--dp-green)' : 'var(--dp-red)' }}>
          {fixed ? 'RESTORED' : `${remaining} pixels off`}
        </span>
      </p>

      <PixelEditor value={draft} onChange={setDraft} ghost={savedPixels} />

      <button type="button" className="dp-btn" onClick={done} disabled={!fixed}>
        Done
      </button>
    </Screen>
  )
}
