'use client'

/**
 * Stage 9 — Drag Corruption. The cursor tracks normally, but the dragged block
 * now moves OPPOSITE to your hand. Push right, it goes left. Glitch feedback
 * nags: "YOU'RE DOING IT WRONG." Completable: mirrored control still reaches
 * the box, and disabling invert FX restores normal dragging.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { corrupt } from '@/lib/pixel-utils'
import { inside, useVirtualFrame } from '@/components/use-virtual-pointer'

export function DragScreen() {
  const { advance, savedPixels, settings, setCorruption } = useExperience()
  const objRef = useRef<HTMLDivElement>(null)
  const boxRef = useRef<HTMLDivElement>(null)
  const draggingRef = useRef(false)
  const last = useRef({ x: 0, y: 0 })
  const pos = useRef({ x: 0, y: 0 })
  const prevDist = useRef(Infinity)
  const [nagging, setNagging] = useState(false)
  const [done, setDone] = useState(false)

  const pixels = useMemo(() => corrupt(savedPixels, 0.28, 44), [savedPixels])

  useEffect(() => {
    pos.current = { x: window.innerWidth * 0.3, y: window.innerHeight * 0.55 }
    if (objRef.current) {
      objRef.current.style.left = `${pos.current.x}px`
      objRef.current.style.top = `${pos.current.y}px`
    }
  }, [])

  useEffect(() => {
    const down = () => {
      const el = objRef.current
      if (!el) return
      const { virtualX: x, virtualY: y } = pointerNow()
      if (inside(x, y, el.getBoundingClientRect())) {
        draggingRef.current = true
        last.current = { x, y }
      }
    }
    const up = () => {
      draggingRef.current = false
      const box = boxRef.current
      const obj = objRef.current
      if (box && obj) {
        const b = box.getBoundingClientRect()
        const o = obj.getBoundingClientRect()
        if (inside(o.left + o.width / 2, o.top + o.height / 2, b)) {
          setDone(true)
          setCorruption(0.7)
        }
      }
    }
    window.addEventListener('pointerdown', down)
    window.addEventListener('pointerup', up)
    return () => {
      window.removeEventListener('pointerdown', down)
      window.removeEventListener('pointerup', up)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Read pointer imperatively from the shared ref via a tiny helper.
  const { pointer } = useExperience()
  const pointerNow = () => pointer.current

  useVirtualFrame((x, y) => {
    if (!draggingRef.current || !objRef.current) return
    const dx = x - last.current.x
    const dy = y - last.current.y
    last.current = { x, y }

    // Opposite movement (unless invert FX disabled → normal drag).
    const sign = settings.allowInvert ? -1 : 1
    pos.current.x = Math.max(20, Math.min(window.innerWidth - 20, pos.current.x + dx * sign))
    pos.current.y = Math.max(20, Math.min(window.innerHeight - 20, pos.current.y + dy * sign))
    objRef.current.style.left = `${pos.current.x}px`
    objRef.current.style.top = `${pos.current.y}px`

    // Nag when the block is drifting away from the box.
    const box = boxRef.current?.getBoundingClientRect()
    if (box) {
      const cx = box.left + box.width / 2
      const cy = box.top + box.height / 2
      const dist = Math.hypot(pos.current.x - cx, pos.current.y - cy)
      if (dist > prevDist.current + 2) setNagging(true)
      else if (dist < prevDist.current - 2) setNagging(false)
      prevDist.current = dist
    }
  }, !done)

  return (
    <>
      <CursorEngine pixels={pixels} active behavior={{ drift: 1.8 }} />

      <div
        style={{
          position: 'fixed',
          top: '3rem',
          left: 0,
          right: 0,
          textAlign: 'center',
          zIndex: 5,
        }}
      >
        <GlitchText
          as="h2"
          glitch={nagging}
          style={{
            fontSize: '0.95rem',
            color: nagging ? 'var(--dp-red)' : 'var(--dp-green)',
          }}
        >
          {done
            ? 'DONE.'
            : nagging
              ? "YOU'RE DOING IT WRONG."
              : 'DRAG THE BLOCK INTO THE BOX.'}
        </GlitchText>
      </div>

      <div
        ref={boxRef}
        className="font-terminal"
        style={{
          position: 'fixed',
          right: '16%',
          top: '52%',
          width: 140,
          height: 140,
          transform: 'translateY(-50%)',
          border: '2px dashed var(--dp-cyan)',
          display: 'grid',
          placeItems: 'center',
          color: 'var(--dp-cyan)',
        }}
      >
        DROP HERE
      </div>

      {!done && (
        <div
          ref={objRef}
          style={{
            position: 'fixed',
            width: 58,
            height: 58,
            transform: 'translate(-50%, -50%)',
            background: nagging ? 'var(--dp-red)' : 'var(--dp-green)',
            boxShadow: '0 0 16px rgba(53,255,124,0.5)',
            transition: 'background 0.2s',
          }}
        />
      )}

      {done && (
        <button
          type="button"
          className="dp-btn"
          onClick={advance}
          style={{
            position: 'fixed',
            left: '50%',
            top: '62%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          Continue
        </button>
      )}
    </>
  )
}
