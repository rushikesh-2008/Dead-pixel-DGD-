'use client'

/**
 * Stage 7 — Cursor Personality. The cursor now has opinions: it drifts, leaves
 * dead-pixel trails, occasionally freezes, mutates a pixel now and then, and
 * gently shies away from the button you are trying to press. Messages use the
 * cursor's name.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { corrupt } from '@/lib/pixel-utils'
import { inside, useVirtualClick } from '@/components/use-virtual-pointer'

export function PersonalityScreen() {
  const { advance, savedPixels, name } = useExperience()
  const btnRef = useRef<HTMLButtonElement>(null)
  const [center, setCenter] = useState({ x: 0, y: 0 })
  const [msgIndex, setMsgIndex] = useState(0)

  const cursorName = name || 'PIXEL'
  const messages = useMemo(
    () => [
      `${cursorName} IS MOVING.`,
      `${cursorName} IS SHEDDING PIXELS.`,
      `${cursorName} HAS OPINIONS NOW.`,
    ],
    [cursorName],
  )

  // Slowly corrupt the design while this stage is active.
  const pixels = useMemo(() => corrupt(savedPixels, 0.12, 21), [savedPixels])

  useEffect(() => {
    const measure = () => {
      const r = btnRef.current?.getBoundingClientRect()
      if (r) setCenter({ x: r.left + r.width / 2, y: r.top + r.height / 2 })
    }
    measure()
    window.addEventListener('resize', measure)
    const rot = setInterval(
      () => setMsgIndex((i) => (i + 1) % messages.length),
      2600,
    )
    return () => {
      window.removeEventListener('resize', measure)
      clearInterval(rot)
    }
  }, [messages.length])

  // The button can be pressed with the *virtual* cursor — chase it a little.
  useVirtualClick((x, y) => {
    const el = btnRef.current
    if (el && inside(x, y, el.getBoundingClientRect())) advance()
  })

  return (
    <>
      <CursorEngine
        pixels={pixels}
        active
        behavior={{
          drift: 2,
          trail: true,
          autonomy: 0.12,
          ignoreChance: 0.45,
          repelFrom: center,
          repelRadius: 95,
        }}
      />
      <div
        style={{
          position: 'fixed',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '2.5rem',
          zIndex: 5,
        }}
      >
        <GlitchText style={{ fontSize: 'clamp(1rem, 3.4vw, 1.9rem)' }}>
          {messages[msgIndex]}
        </GlitchText>
        <button ref={btnRef} type="button" className="dp-btn">
          Calm It Down
        </button>
        <p
          className="font-terminal"
          style={{ color: 'var(--dp-green-dim)', fontSize: '1rem', maxWidth: 420 }}
        >
          press the button. if you can catch it.
        </p>
      </div>
    </>
  )
}
