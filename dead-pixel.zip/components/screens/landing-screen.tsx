'use client'

import { useExperience } from '@/lib/experience-context'
import { Screen } from '@/components/crt-frame'
import { GlitchText } from '@/components/glitch-text'

export function LandingScreen() {
  const { advance } = useExperience()
  return (
    <>
      <Screen powerOn>
        <GlitchText style={{ fontSize: 'clamp(1.4rem, 5vw, 3rem)' }}>
          YOUR CURSOR IS BORING.
        </GlitchText>
        <p
          className="font-terminal"
          style={{
            fontSize: 'clamp(1.2rem, 3vw, 1.8rem)',
            color: 'var(--dp-green-dim)',
            margin: 0,
          }}
        >
          {"Let's fix that."}
        </p>
        <button type="button" className="dp-btn" onClick={advance} style={{ marginTop: '1rem' }}>
          Build Your Cursor
        </button>
      </Screen>
      <p
        className="font-terminal"
        style={{
          position: 'fixed',
          bottom: 16,
          left: 0,
          right: 0,
          textAlign: 'center',
          fontSize: '0.9rem',
          color: 'var(--dp-green-dim)',
          opacity: 0.6,
          zIndex: 5,
        }}
      >
        headphones optional. patience recommended.
      </p>
    </>
  )
}
