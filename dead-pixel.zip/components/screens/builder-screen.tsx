'use client'

import { useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { Screen } from '@/components/crt-frame'
import { GlitchText } from '@/components/glitch-text'
import { PixelEditor } from '@/components/pixel-editor'
import { hasPixels } from '@/lib/pixel-utils'

export function BuilderScreen() {
  const { advance, saveDesign, savedPixels } = useExperience()
  const [draft, setDraft] = useState<string[]>(savedPixels)

  const done = () => {
    if (!hasPixels(draft)) return
    saveDesign(draft)
    advance()
  }

  return (
    <Screen>
      <GlitchText as="h2" style={{ fontSize: 'clamp(1rem, 3vw, 1.6rem)' }}>
        BUILD YOUR CURSOR
      </GlitchText>
      <p
        className="font-terminal"
        style={{ color: 'var(--dp-green-dim)', margin: 0, fontSize: '1.1rem' }}
      >
        16 x 16 pixels. draw it. own it.
      </p>

      <PixelEditor value={draft} onChange={setDraft} showTemplates />

      <button
        type="button"
        className="dp-btn"
        onClick={done}
        disabled={!hasPixels(draft)}
      >
        Done
      </button>
    </Screen>
  )
}
