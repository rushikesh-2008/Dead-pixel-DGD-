'use client'

/**
 * Stage 8 — Mouse Corruption. Inversion is introduced gradually across three
 * targets: 10% -> 50% -> 100% mirrored. Never explained; the player discovers
 * that moving right sends the cursor left. Accessibility: if invert FX are
 * disabled the ratio is neutralised by the engine and targets still work.
 */

import { useMemo, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { corrupt } from '@/lib/pixel-utils'
import { inside, useVirtualClick } from '@/components/use-virtual-pointer'

const RATIOS = [0.1, 0.5, 1]

function randomSpot() {
  return {
    left: 15 + Math.random() * 70,
    top: 25 + Math.random() * 55,
  }
}

export function InvertScreen() {
  const { advance, savedPixels, setCorruption } = useExperience()
  const [subStage, setSubStage] = useState(0)
  const [spot, setSpot] = useState(randomSpot)
  const targetRef = useRef<HTMLButtonElement>(null)

  const pixels = useMemo(() => corrupt(savedPixels, 0.18, 33), [savedPixels])

  useVirtualClick((x, y) => {
    const el = targetRef.current
    if (!el) return
    if (inside(x, y, el.getBoundingClientRect())) {
      const next = subStage + 1
      setCorruption(0.2 + next * 0.15)
      if (next >= RATIOS.length) {
        advance()
      } else {
        setSubStage(next)
        setSpot(randomSpot())
      }
    }
  })

  return (
    <>
      <CursorEngine
        pixels={pixels}
        active
        behavior={{ invertRatio: RATIOS[subStage], drift: 1.4 }}
      />
      <div
        style={{
          position: 'fixed',
          top: '3rem',
          left: 0,
          right: 0,
          textAlign: 'center',
          zIndex: 5,
        }}
      >
        <GlitchText as="h2" style={{ fontSize: '0.9rem' }}>
          CALIBRATION
        </GlitchText>
        <p
          className="font-terminal"
          style={{ color: 'var(--dp-green-dim)', fontSize: '1.1rem', marginTop: 8 }}
        >
          reach the target. {subStage + 1} / {RATIOS.length}
        </p>
      </div>

      <button
        ref={targetRef}
        type="button"
        className="font-pixel"
        style={{
          position: 'fixed',
          left: `${spot.left}%`,
          top: `${spot.top}%`,
          transform: 'translate(-50%, -50%)',
          width: 74,
          height: 74,
          borderRadius: '50%',
          border: '3px solid var(--dp-cyan)',
          background: 'rgba(87,247,255,0.08)',
          color: 'var(--dp-cyan)',
          fontSize: '0.5rem',
          cursor: 'none',
          boxShadow: '0 0 18px rgba(87,247,255,0.4)',
        }}
      >
        HIT
      </button>
    </>
  )
}
