'use client'

/**
 * Stage 10 — Cursor Becomes Independent. The cursor is now offset from the
 * mouse, wanders on its own, and sometimes ignores input entirely. The player
 * must account for the gap. Message: "MOUSE MOVEMENT ≠ CURSOR MOVEMENT."
 */

import { useMemo, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { corrupt } from '@/lib/pixel-utils'
import { inside, useVirtualFrame } from '@/components/use-virtual-pointer'

export function IndependentScreen() {
  const { advance, savedPixels, name } = useExperience()
  const targetRef = useRef<HTMLDivElement>(null)
  const dwellRef = useRef(0)
  const [dwell, setDwell] = useState(0)

  const pixels = useMemo(() => corrupt(savedPixels, 0.4, 55), [savedPixels])
  const cursorName = name || 'PIXEL'

  useVirtualFrame((x, y, dt) => {
    const el = targetRef.current
    if (!el) return
    if (inside(x, y, el.getBoundingClientRect())) {
      dwellRef.current += dt
      setDwell(Math.min(1, dwellRef.current / 0.8))
      if (dwellRef.current >= 0.8) advance()
    } else {
      dwellRef.current = Math.max(0, dwellRef.current - dt * 0.5)
      setDwell(Math.min(1, dwellRef.current / 0.8))
    }
  })

  return (
    <>
      <CursorEngine
        pixels={pixels}
        active
        behavior={{
          offset: { x: 64, y: -54 },
          autonomy: 0.22,
          ignoreChance: 0.5,
          drift: 2.2,
          trail: true,
        }}
      />
      <div
        style={{
          position: 'fixed',
          top: '3rem',
          left: 0,
          right: 0,
          textAlign: 'center',
          zIndex: 5,
          padding: '0 1rem',
        }}
      >
        <GlitchText style={{ fontSize: 'clamp(0.9rem, 3vw, 1.5rem)' }}>
          MOUSE MOVEMENT ≠ CURSOR MOVEMENT
        </GlitchText>
        <p
          className="font-terminal"
          style={{ color: 'var(--dp-green-dim)', fontSize: '1.1rem', marginTop: 10 }}
        >
          hold {cursorName} on the ring.
        </p>
      </div>

      <div
        ref={targetRef}
        style={{
          position: 'fixed',
          left: '50%',
          top: '52%',
          width: 110,
          height: 110,
          transform: 'translate(-50%, -50%)',
          borderRadius: '50%',
          border: '2px solid var(--dp-cyan)',
          display: 'grid',
          placeItems: 'center',
          boxShadow: `0 0 ${8 + dwell * 26}px rgba(87,247,255,${0.25 + dwell * 0.5})`,
        }}
      >
        <div
          style={{
            width: 22 + dwell * 52,
            height: 22 + dwell * 52,
            borderRadius: '50%',
            background: 'var(--dp-cyan)',
            opacity: 0.35 + dwell * 0.6,
          }}
        />
      </div>
    </>
  )
}
