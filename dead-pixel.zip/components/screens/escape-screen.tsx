'use client'

/**
 * Stage 11 — Cursor Escape. A "CLICK ME" button the cursor actively flees from.
 * The player chases it. After a while the truth surfaces: "IT DOESN'T WANT TO."
 * then "IT'S WHERE IT WANTS TO BE." A guaranteed exit appears so the stage can
 * always be completed.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { corrupt } from '@/lib/pixel-utils'
import { inside, useVirtualClick, useVirtualFrame } from '@/components/use-virtual-pointer'

export function EscapeScreen() {
  const { advance, savedPixels, settings } = useExperience()
  const btnRef = useRef<HTMLButtonElement>(null)
  const [center, setCenter] = useState({ x: 0, y: 0 })
  const [phase, setPhase] = useState(0) // 0 chase, 1 doesn't want to, 2 where it wants
  const tRef = useRef(0)

  const pixels = useMemo(() => corrupt(savedPixels, 0.5, 66), [savedPixels])

  useEffect(() => {
    const measure = () => {
      const r = btnRef.current?.getBoundingClientRect()
      if (r) setCenter({ x: r.left + r.width / 2, y: r.top + r.height / 2 })
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [phase])

  useVirtualFrame((x, y, dt) => {
    tRef.current += dt
    if (tRef.current > 12) setPhase((p) => (p < 2 ? 2 : p))
    else if (tRef.current > 7) setPhase((p) => (p < 1 ? 1 : p))
  }, phase < 2)

  // If they somehow corner it, skip straight to the reveal.
  useVirtualClick((x, y) => {
    const el = btnRef.current
    if (el && inside(x, y, el.getBoundingClientRect())) {
      tRef.current = 12
      setPhase(2)
    }
  }, phase < 2)

  const message =
    phase === 2
      ? "IT'S WHERE IT WANTS TO BE."
      : phase === 1
        ? "IT DOESN'T WANT TO."
        : 'CLICK ME.'

  return (
    <>
      <CursorEngine
        pixels={pixels}
        active
        behavior={{
          repelFrom: settings.allowInvert ? center : null,
          repelRadius: 230,
          invertRatio: 0.25,
          drift: 2,
          trail: true,
        }}
      />

      <div
        style={{
          position: 'fixed',
          top: '3rem',
          left: 0,
          right: 0,
          textAlign: 'center',
          zIndex: 5,
        }}
      >
        <GlitchText style={{ fontSize: 'clamp(1rem, 3.4vw, 1.9rem)' }}>
          {message}
        </GlitchText>
      </div>

      {phase < 2 ? (
        <button
          ref={btnRef}
          type="button"
          className="dp-btn"
          style={{
            position: 'fixed',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          Click Me
        </button>
      ) : (
        <button
          type="button"
          className="dp-btn dp-fade-in"
          onClick={advance}
          style={{
            position: 'fixed',
            left: '50%',
            top: '58%',
            transform: 'translate(-50%, -50%)',
            borderColor: 'var(--dp-red)',
            color: 'var(--dp-red)',
          }}
        >
          Let It Go
        </button>
      )}
    </>
  )
}
