'use client'

/**
 * Stage 13 — Final Reveal. Black screen, messages surfacing one by one, then
 * the cursor returns — subtly different from the original design, drifting on
 * its own. Offers a restart.
 */

import { useEffect, useMemo, useState } from 'react'
import { useExperience } from '@/lib/experience-context'
import { CursorEngine } from '@/components/cursor-engine'
import { GlitchText } from '@/components/glitch-text'
import { nudgeOnePixel } from '@/lib/pixel-utils'

export function RevealScreen() {
  const { savedPixels, name, reset } = useExperience()
  const cursorName = name || 'PIXEL'

  const lines = useMemo(
    () => [
      'YOU BUILT IT.',
      'YOU NAMED IT.',
      'YOU TAUGHT IT HOW TO MOVE.',
      'NOW IT KNOWS HOW TO MOVE WITHOUT YOU.',
      `THANK YOU, ${cursorName}.`,
    ],
    [cursorName],
  )

  const [step, setStep] = useState(-1)
  const [revealCursor, setRevealCursor] = useState(false)

  // The cursor returns, subtly altered from the original.
  const finalPixels = useMemo(() => nudgeOnePixel(savedPixels, 3), [savedPixels])

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = []
    timers.push(setTimeout(() => setStep(0), 900))
    for (let i = 1; i < lines.length; i++) {
      timers.push(setTimeout(() => setStep(i), 900 + i * 2200))
    }
    timers.push(
      setTimeout(() => setRevealCursor(true), 900 + lines.length * 2200 + 600),
    )
    return () => timers.forEach(clearTimeout)
  }, [lines.length])

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: '#000',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '2rem',
        zIndex: 30,
        textAlign: 'center',
        padding: '1rem',
      }}
    >
      {step >= 0 && !revealCursor && (
        <GlitchText
          key={step}
          className="dp-fade-in"
          style={{ fontSize: 'clamp(1rem, 3.6vw, 2rem)' }}
        >
          {lines[step]}
        </GlitchText>
      )}

      {revealCursor && (
        <>
          <CursorEngine
            pixels={finalPixels}
            active
            cell={3}
            behavior={{
              autonomy: 0.35,
              drift: 2,
              trail: true,
              ignoreChance: 0.4,
            }}
          />
          <GlitchText
            className="dp-fade-in"
            style={{ fontSize: 'clamp(1rem, 3.6vw, 2rem)' }}
          >
            {`THANK YOU, ${cursorName}.`}
          </GlitchText>
          <p
            className="font-terminal dp-fade-in"
            style={{ color: 'var(--dp-green-dim)', fontSize: '1.1rem', maxWidth: 420 }}
          >
            it still remembers you.
          </p>
          <button
            type="button"
            className="dp-btn dp-fade-in"
            onClick={reset}
            style={{ marginTop: '1rem' }}
          >
            Build Another
          </button>
        </>
      )}
    </div>
  )
}
