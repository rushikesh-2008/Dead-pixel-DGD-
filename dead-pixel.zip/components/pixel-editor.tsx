'use client'

/**
 * PixelEditor — a reusable 16x16 canvas editor.
 *
 * Tools: pencil, eraser, fill (flood), clear, undo.
 * Optional template picker (builder) and a faint `ghost` overlay used by the
 * repair screen to show the original design the player is restoring toward.
 * A live preview applies the design as a real CSS cursor.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  GRID,
  PALETTE,
  TEMPLATES,
  type TemplateId,
  drawPixels,
  pixelsToDataURL,
} from '@/lib/pixel-utils'

const CELL = 24
const SIZE = CELL * GRID

type Tool = 'pencil' | 'eraser' | 'fill'

export function PixelEditor({
  value,
  onChange,
  showTemplates = false,
  ghost = null,
}: {
  value: string[]
  onChange: (pixels: string[]) => void
  showTemplates?: boolean
  ghost?: string[] | null
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [colorIdx, setColorIdx] = useState(3) // phosphor green
  const [tool, setTool] = useState<Tool>('pencil')
  const [history, setHistory] = useState<string[][]>([])
  const drawingRef = useRef(false)
  const valueRef = useRef(value)
  valueRef.current = value

  // --- Redraw whenever the design (or ghost) changes ---
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.clearRect(0, 0, SIZE, SIZE)

    // Transparency checkerboard.
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? '#0a1014' : '#0d1519'
        ctx.fillRect(x * CELL, y * CELL, CELL, CELL)
      }
    }

    // Ghost / target overlay (repair mode).
    if (ghost) {
      ctx.globalAlpha = 0.18
      drawPixels(ctx, ghost, CELL)
      ctx.globalAlpha = 1
    }

    drawPixels(ctx, value, CELL, { grid: true })
  }, [value, ghost])

  const pushHistory = useCallback(() => {
    setHistory((h) => [...h.slice(-40), [...valueRef.current]])
  }, [])

  const cellFromEvent = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * GRID)
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * GRID)
    if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1
    return y * GRID + x
  }

  const floodFill = (idx: number, target: string, replacement: string) => {
    if (target === replacement) return valueRef.current
    const next = [...valueRef.current]
    const stack = [idx]
    while (stack.length) {
      const i = stack.pop() as number
      if (next[i] !== target) continue
      next[i] = replacement
      const x = i % GRID
      const y = Math.floor(i / GRID)
      if (x > 0) stack.push(i - 1)
      if (x < GRID - 1) stack.push(i + 1)
      if (y > 0) stack.push(i - GRID)
      if (y < GRID - 1) stack.push(i + GRID)
    }
    return next
  }

  const paintAt = (idx: number) => {
    if (idx < 0) return
    const color = tool === 'eraser' ? '' : PALETTE[colorIdx]
    if (tool === 'fill') {
      onChange(floodFill(idx, valueRef.current[idx], color))
      return
    }
    if (valueRef.current[idx] === color) return
    const next = [...valueRef.current]
    next[idx] = color
    onChange(next)
  }

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    pushHistory()
    drawingRef.current = tool !== 'fill'
    paintAt(cellFromEvent(e))
  }
  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return
    paintAt(cellFromEvent(e))
  }
  const endStroke = () => {
    drawingRef.current = false
  }

  const undo = () => {
    setHistory((h) => {
      if (h.length === 0) return h
      const prev = h[h.length - 1]
      onChange([...prev])
      return h.slice(0, -1)
    })
  }

  const clear = () => {
    pushHistory()
    onChange(new Array(GRID * GRID).fill(''))
  }

  const applyTemplate = (id: TemplateId) => {
    pushHistory()
    onChange(TEMPLATES[id]())
  }

  const cursorUrl = useMemo(() => pixelsToDataURL(value, 2), [value])

  const toolBtn = (t: Tool, label: string) => (
    <button
      type="button"
      onClick={() => setTool(t)}
      className="font-pixel"
      style={{
        fontSize: '0.55rem',
        padding: '8px 10px',
        textTransform: 'uppercase',
        color: tool === t ? 'var(--dp-bg)' : 'var(--dp-green)',
        background: tool === t ? 'var(--dp-green)' : 'transparent',
        border: '2px solid var(--dp-green)',
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  )

  return (
    <div
      style={{
        display: 'flex',
        gap: '1.5rem',
        flexWrap: 'wrap',
        justifyContent: 'center',
        alignItems: 'flex-start',
      }}
    >
      {/* Canvas */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <canvas
          ref={canvasRef}
          width={SIZE}
          height={SIZE}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endStroke}
          onPointerLeave={endStroke}
          aria-label="Pixel cursor editor grid"
          style={{
            width: 'min(384px, 78vw)',
            height: 'min(384px, 78vw)',
            imageRendering: 'pixelated',
            border: '2px solid var(--dp-green)',
            boxShadow: '0 0 24px rgba(53,255,124,0.25)',
            touchAction: 'none',
            background: '#0a1014',
          }}
        />
        <div
          style={{
            display: 'flex',
            gap: 8,
            flexWrap: 'wrap',
            justifyContent: 'center',
          }}
        >
          {toolBtn('pencil', 'Pencil')}
          {toolBtn('eraser', 'Eraser')}
          {toolBtn('fill', 'Fill')}
          <button
            type="button"
            onClick={undo}
            disabled={history.length === 0}
            className="dp-btn dp-btn--ghost"
            style={{ fontSize: '0.55rem', padding: '8px 10px' }}
          >
            Undo
          </button>
          <button
            type="button"
            onClick={clear}
            className="dp-btn dp-btn--ghost"
            style={{
              fontSize: '0.55rem',
              padding: '8px 10px',
              borderColor: 'var(--dp-red)',
              color: 'var(--dp-red)',
            }}
          >
            Clear
          </button>
        </div>
      </div>

      {/* Side panel: palette, templates, preview */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '1.25rem',
          minWidth: 180,
          alignItems: 'flex-start',
        }}
      >
        <div>
          <p className="font-pixel" style={labelStyle}>
            Palette
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(6, 26px)',
              gap: 6,
            }}
          >
            {PALETTE.map((c, i) => (
              <button
                key={i}
                type="button"
                aria-label={c ? `Color ${c}` : 'Transparent'}
                data-active={i === colorIdx && tool !== 'eraser'}
                onClick={() => {
                  setColorIdx(i)
                  if (tool === 'eraser') setTool('pencil')
                }}
                className="dp-swatch"
                style={{
                  background: c
                    ? c
                    : 'repeating-conic-gradient(#333 0% 25%, #111 0% 50%) 0/12px 12px',
                }}
              />
            ))}
          </div>
        </div>

        {showTemplates && (
          <div>
            <p className="font-pixel" style={labelStyle}>
              Templates
            </p>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {(['arrow', 'hand', 'cross', 'custom'] as TemplateId[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => applyTemplate(id)}
                  className="font-pixel"
                  style={{
                    fontSize: '0.5rem',
                    padding: '6px 8px',
                    textTransform: 'uppercase',
                    color: 'var(--dp-cyan)',
                    background: 'transparent',
                    border: '1px solid var(--dp-cyan)',
                    cursor: 'pointer',
                  }}
                >
                  {id}
                </button>
              ))}
            </div>
          </div>
        )}

        <div>
          <p className="font-pixel" style={labelStyle}>
            Live Preview
          </p>
          <div
            title="Move your mouse here"
            style={{
              width: 160,
              height: 90,
              border: '1px dashed var(--dp-green-dim)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: cursorUrl ? `url(${cursorUrl}) 0 0, auto` : 'auto',
              color: 'var(--dp-green-dim)',
              fontSize: '0.8rem',
            }}
          >
            hover me
          </div>
          <img
            src={cursorUrl || '/placeholder.svg'}
            alt="Cursor preview"
            width={48}
            height={48}
            style={{
              imageRendering: 'pixelated',
              marginTop: 10,
              border: '1px solid var(--dp-line)',
              background: '#0a1014',
            }}
          />
        </div>
      </div>
    </div>
  )
}

const labelStyle: React.CSSProperties = {
  fontSize: '0.55rem',
  color: 'var(--dp-green-dim)',
  textTransform: 'uppercase',
  margin: '0 0 8px',
}
