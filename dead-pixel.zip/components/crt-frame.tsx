'use client'

/**
 * CrtFrame — wraps the whole experience in scanlines, a vignette and an
 * optional flicker. The flicker is suppressed when the user disables glitch
 * effects (accessibility) or prefers reduced motion.
 */

import { useExperience } from '@/lib/experience-context'

export function CrtFrame({ children }: { children: React.ReactNode }) {
  const { settings } = useExperience()
  return (
    <div
      className={`crt-scanlines crt-vignette ${settings.allowGlitch ? 'crt-flicker' : ''}`}
      style={{
        position: 'fixed',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {children}
    </div>
  )
}

/** A centred screen container with a soft power-on / fade-in. */
export function Screen({
  children,
  className = '',
  powerOn = false,
}: {
  children: React.ReactNode
  className?: string
  powerOn?: boolean
}) {
  return (
    <section
      className={`${powerOn ? 'dp-power-on' : 'dp-fade-in'} ${className}`}
      style={{
        position: 'relative',
        width: 'min(920px, 92vw)',
        maxHeight: '92vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '1.5rem',
        textAlign: 'center',
        padding: '1.5rem',
      }}
    >
      {children}
    </section>
  )
}
