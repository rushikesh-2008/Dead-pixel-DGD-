'use client'

/**
 * TerminalLines — types out an ordered list of lines like a boot log, then
 * calls `onDone`. Respects reduced-motion by rendering instantly.
 */

import { useEffect, useRef, useState } from 'react'

export function TerminalLines({
  lines,
  speed = 34,
  linePause = 380,
  onDone,
  className = '',
}: {
  lines: string[]
  speed?: number
  linePause?: number
  onDone?: () => void
  className?: string
}) {
  const [display, setDisplay] = useState<string[]>([])
  const [current, setCurrent] = useState('')
  const doneRef = useRef(false)

  useEffect(() => {
    doneRef.current = false
    setDisplay([])
    setCurrent('')

    const reduce =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches

    if (reduce) {
      setDisplay(lines)
      const t = setTimeout(() => onDone?.(), 400)
      return () => clearTimeout(t)
    }

    let li = 0
    let ci = 0
    let timer: ReturnType<typeof setTimeout>

    const step = () => {
      if (li >= lines.length) {
        if (!doneRef.current) {
          doneRef.current = true
          onDone?.()
        }
        return
      }
      const line = lines[li]
      if (ci <= line.length) {
        setCurrent(line.slice(0, ci))
        ci++
        timer = setTimeout(step, speed)
      } else {
        setDisplay((d) => [...d, line])
        setCurrent('')
        li++
        ci = 0
        timer = setTimeout(step, linePause)
      }
    }
    timer = setTimeout(step, 300)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines])

  return (
    <div
      className={`font-terminal ${className}`}
      style={{
        fontSize: 'clamp(1.1rem, 2.4vw, 1.6rem)',
        color: 'var(--dp-green)',
        textAlign: 'left',
        width: '100%',
        maxWidth: 640,
        margin: '0 auto',
        lineHeight: 1.7,
        minHeight: '10rem',
      }}
      aria-live="polite"
    >
      {display.map((l, i) => (
        <div key={i}>
          <span style={{ color: 'var(--dp-green-dim)' }}>{'> '}</span>
          {l}
        </div>
      ))}
      {current && (
        <div>
          <span style={{ color: 'var(--dp-green-dim)' }}>{'> '}</span>
          {current}
          <span className="dp-caret">█</span>
        </div>
      )}
    </div>
  )
}
