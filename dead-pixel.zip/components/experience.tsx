'use client'

/**
 * Experience — top-level orchestrator. Provides state, wraps everything in the
 * CRT frame + accessibility bar, and routes the current stage to its screen.
 * The stage machine is linear and deterministic (see STAGES in the context).
 */

import { ExperienceProvider, useExperience } from '@/lib/experience-context'
import { CrtFrame } from '@/components/crt-frame'
import { AccessibilityBar } from '@/components/accessibility-bar'
import { LandingScreen } from '@/components/screens/landing-screen'
import { InitScreen } from '@/components/screens/init-screen'
import { BuilderScreen } from '@/components/screens/builder-screen'
import { NameScreen } from '@/components/screens/name-screen'
import { TestScreen } from '@/components/screens/test-screen'
import { GlitchScreen } from '@/components/screens/glitch-screen'
import { PersonalityScreen } from '@/components/screens/personality-screen'
import { InvertScreen } from '@/components/screens/invert-screen'
import { DragScreen } from '@/components/screens/drag-screen'
import { IndependentScreen } from '@/components/screens/independent-screen'
import { EscapeScreen } from '@/components/screens/escape-screen'
import { RepairScreen } from '@/components/screens/repair-screen'
import { RevealScreen } from '@/components/screens/reveal-screen'

function StageRouter() {
  const { stage } = useExperience()
  switch (stage) {
    case 'landing':
      return <LandingScreen />
    case 'init':
      return <InitScreen />
    case 'builder':
      return <BuilderScreen />
    case 'name':
      return <NameScreen />
    case 'test':
      return <TestScreen />
    case 'glitch':
      return <GlitchScreen />
    case 'personality':
      return <PersonalityScreen />
    case 'invert':
      return <InvertScreen />
    case 'drag':
      return <DragScreen />
    case 'independent':
      return <IndependentScreen />
    case 'escape':
      return <EscapeScreen />
    case 'repair':
      return <RepairScreen />
    case 'reveal':
      return <RevealScreen />
    default:
      return <LandingScreen />
  }
}

export function Experience() {
  return (
    <ExperienceProvider>
      <CrtFrame>
        <StageRouter />
      </CrtFrame>
      <AccessibilityBar />
    </ExperienceProvider>
  )
}
