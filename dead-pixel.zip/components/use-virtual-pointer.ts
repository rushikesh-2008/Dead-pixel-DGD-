'use client'

/**
 * Hooks for interacting with the *virtual* cursor position (where the rendered
 * cursor actually is), rather than the raw mouse. Stage mini-games use these so
 * that once corruption sets in, tasks respond to the cursor the player sees.
 */

import { useEffect, useRef } from 'react'
import { useExperience } from '@/lib/experience-context'

/** Call `onClick(x, y)` on pointerdown using the virtual cursor coordinates. */
export function useVirtualClick(
  onClick: (x: number, y: number) => void,
  active = true,
) {
  const { pointer } = useExperience()
  const cb = useRef(onClick)
  cb.current = onClick
  useEffect(() => {
    if (!active) return
    const handler = () => {
      cb.current(pointer.current.virtualX, pointer.current.virtualY)
    }
    window.addEventListener('pointerdown', handler)
    return () => window.removeEventListener('pointerdown', handler)
  }, [active, pointer])
}

/** Run `fn(virtualX, virtualY, dt)` every animation frame while `active`. */
export function useVirtualFrame(
  fn: (x: number, y: number, dt: number) => void,
  active = true,
) {
  const { pointer } = useExperience()
  const cb = useRef(fn)
  cb.current = fn
  useEffect(() => {
    if (!active) return
    let raf = 0
    let prev = performance.now()
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - prev) / 1000)
      prev = now
      cb.current(pointer.current.virtualX, pointer.current.virtualY, dt)
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [active, pointer])
}

export function inside(
  x: number,
  y: number,
  rect: { left: number; top: number; width: number; height: number },
) {
  return (
    x >= rect.left &&
    x <= rect.left + rect.width &&
    y >= rect.top &&
    y <= rect.top + rect.height
  )
}
