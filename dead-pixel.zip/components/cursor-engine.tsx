'use client'

/**
 * CursorEngine — the custom cursor renderer + movement brain.
 *
 * A single full-screen, pointer-events:none canvas draws the player's pixel
 * cursor at a *virtual* position that may diverge from the real mouse depending
 * on `behavior`. Every frame it publishes both the real and virtual positions
 * into the shared pointer ref so stage mini-games can hit-test against where the
 * cursor actually is (which is the whole point once corruption sets in).
 *
 * Accessibility: when settings disable invert/glitch, all disorienting terms are
 * neutralised so the cursor tracks the mouse 1:1 and every task stays solvable.
 */

import { useEffect, useRef } from 'react'
import { useExperience } from '@/lib/experience-context'
import { GRID, drawPixels } from '@/lib/pixel-utils'

export type CursorBehavior = {
  /** 0 = tracks mouse, 1 = fully mirrored across screen centre. */
  invertRatio?: number
  /** Idle twitch / jitter magnitude in px. */
  drift?: number
  /** Constant positional offset from the mouse. */
  offset?: { x: number; y: number }
  /** 0..1 — how strongly the cursor wanders on its own. */
  autonomy?: number
  /** Probability per second that the cursor freezes and ignores input. */
  ignoreChance?: number
  /** Leave fading dead-pixel trails. */
  trail?: boolean
  /** A point the cursor actively flees from (screen coords). */
  repelFrom?: { x: number; y: number } | null
  /** Radius within which repulsion applies. */
  repelRadius?: number
}

type Props = {
  pixels: string[]
  behavior?: CursorBehavior
  /** Whether the custom cursor is shown + native cursor hidden. */
  active?: boolean
  /** Rendered pixel size of one grid cell. */
  cell?: number
}

type Trail = { x: number; y: number; life: number; color: string }

export function CursorEngine({
  pixels,
  behavior = {},
  active = true,
  cell = 2,
}: Props) {
  const { pointer, settings } = useExperience()
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Mutable render state kept out of React to avoid re-renders each frame.
  const behaviorRef = useRef(behavior)
  const pixelsRef = useRef(pixels)
  const settingsRef = useRef(settings)
  behaviorRef.current = behavior
  pixelsRef.current = pixels
  settingsRef.current = settings

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let dpr = Math.min(window.devicePixelRatio || 1, 2)
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = window.innerWidth * dpr
      canvas.height = window.innerHeight * dpr
      canvas.style.width = `${window.innerWidth}px`
      canvas.style.height = `${window.innerHeight}px`
    }
    resize()
    window.addEventListener('resize', resize)

    // Virtual position (where the cursor is drawn) + autonomous velocity.
    const p = pointer.current
    let vx = p.realX || window.innerWidth / 2
    let vy = p.realY || window.innerHeight / 2
    let wanderT = Math.random() * 1000
    let frozenUntil = 0
    let lastIgnoreRoll = 0
    const trails: Trail[] = []

    const onMove = (e: PointerEvent) => {
      p.realX = e.clientX
      p.realY = e.clientY
    }
    window.addEventListener('pointermove', onMove, { passive: true })

    let raf = 0
    let prev = performance.now()

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - prev) / 1000)
      prev = now

      const b = behaviorRef.current
      const s = settingsRef.current
      const allowInvert = s.allowInvert
      const allowGlitch = s.allowGlitch
      const W = window.innerWidth
      const H = window.innerHeight

      // --- Compute the target position from the real mouse ---
      let tx = p.realX
      let ty = p.realY

      // Inversion: lerp toward the mirrored point.
      const invert = allowInvert ? (b.invertRatio ?? 0) : 0
      if (invert > 0) {
        const mx = W - p.realX
        const my = H - p.realY
        tx = p.realX + (mx - p.realX) * invert
        ty = p.realY + (my - p.realY) * invert
      }

      // Constant offset.
      if (allowInvert && b.offset) {
        tx += b.offset.x
        ty += b.offset.y
      }

      // Autonomous wander.
      const autonomy = allowInvert ? (b.autonomy ?? 0) : 0
      if (autonomy > 0) {
        wanderT += dt
        const wanderX =
          Math.sin(wanderT * 1.3) * 90 + Math.sin(wanderT * 0.7 + 2) * 60
        const wanderY =
          Math.cos(wanderT * 1.1) * 90 + Math.cos(wanderT * 0.5 + 1) * 60
        tx = tx * (1 - autonomy) + (W / 2 + wanderX) * autonomy
        ty = ty * (1 - autonomy) + (H / 2 + wanderY) * autonomy
      }

      // Repulsion (escape stage): flee from a point.
      if (allowInvert && b.repelFrom) {
        const r = b.repelRadius ?? 160
        const dx = tx - b.repelFrom.x
        const dy = ty - b.repelFrom.y
        const dist = Math.hypot(dx, dy) || 0.0001
        if (dist < r) {
          const push = (r - dist) / r
          tx += (dx / dist) * push * r * 1.4
          ty += (dy / dist) * push * r * 1.4
        }
      }

      // Occasionally freeze / ignore input.
      const ignore = allowInvert ? (b.ignoreChance ?? 0) : 0
      if (ignore > 0) {
        lastIgnoreRoll += dt
        if (lastIgnoreRoll > 0.25) {
          lastIgnoreRoll = 0
          if (Math.random() < ignore * 0.25) {
            frozenUntil = now + 200 + Math.random() * 350
          }
        }
      }
      const frozen = now < frozenUntil

      // Keep target on screen.
      tx = Math.max(0, Math.min(W, tx))
      ty = Math.max(0, Math.min(H, ty))

      // --- Ease the virtual cursor toward the target ---
      const ease = frozen ? 0 : autonomy > 0 ? 0.08 : invert > 0 ? 0.22 : 0.35
      vx += (tx - vx) * ease
      vy += (ty - vy) * ease

      // Idle drift / twitch.
      let jx = 0
      let jy = 0
      const drift = allowGlitch ? (b.drift ?? 0) : 0
      if (drift > 0) {
        jx = (Math.random() - 0.5) * drift
        jy = (Math.random() - 0.5) * drift
      }

      const drawX = vx + jx
      const drawY = vy + jy

      // Publish for hit-testing.
      p.virtualX = drawX
      p.virtualY = drawY

      // --- Render ---
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, W, H)

      if (!active) {
        raf = requestAnimationFrame(frame)
        return
      }

      // Dead-pixel trails.
      if (allowGlitch && b.trail) {
        if (Math.random() < 0.5) {
          trails.push({
            x: drawX + (Math.random() - 0.5) * 6,
            y: drawY + (Math.random() - 0.5) * 6,
            life: 1,
            color: Math.random() < 0.5 ? '#35ff7c' : '#ff4d5e',
          })
        }
      }
      for (let i = trails.length - 1; i >= 0; i--) {
        const t = trails[i]
        t.life -= dt * 0.9
        if (t.life <= 0) {
          trails.splice(i, 1)
          continue
        }
        ctx.globalAlpha = t.life * 0.7
        ctx.fillStyle = t.color
        ctx.fillRect(Math.round(t.x), Math.round(t.y), cell, cell)
      }
      ctx.globalAlpha = 1

      // The cursor itself. Hotspot at grid origin (top-left).
      ctx.save()
      ctx.translate(Math.round(drawX), Math.round(drawY))
      drawPixels(ctx, pixelsRef.current, cell)
      ctx.restore()

      raf = requestAnimationFrame(frame)
    }

    raf = requestAnimationFrame(frame)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
      window.removeEventListener('pointermove', onMove)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pointer, cell])

  // Toggle native cursor visibility on the body.
  useEffect(() => {
    document.body.dataset.cursorHidden = active ? 'true' : 'false'
    return () => {
      document.body.dataset.cursorHidden = 'false'
    }
  }, [active])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 50,
        pointerEvents: 'none',
      }}
    />
  )
}

// Re-export for convenience.
export { GRID }
