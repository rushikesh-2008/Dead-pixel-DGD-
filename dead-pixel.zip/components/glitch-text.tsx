'use client'

/**
 * GlitchText — pixel-font headline with optional RGB-split glitch layers.
 * Glitch layers are omitted when the user disables glitch effects.
 */

import { useExperience } from '@/lib/experience-context'

export function GlitchText({
  children,
  as: Tag = 'h1',
  glitch = true,
  className = '',
  style,
}: {
  children: string
  as?: 'h1' | 'h2' | 'h3' | 'p' | 'span'
  glitch?: boolean
  className?: string
  style?: React.CSSProperties
}) {
  const { settings } = useExperience()
  const on = glitch && settings.allowGlitch
  return (
    <Tag
      className={`font-pixel dp-glow ${on ? 'dp-glitch' : ''} ${className}`}
      data-glitch={on ? children : undefined}
      style={{
        color: 'var(--dp-green)',
        lineHeight: 1.5,
        margin: 0,
        ...style,
      }}
    >
      {children}
    </Tag>
  )
}
