'use client'

/**
 * AccessibilityBar — always-reachable escape hatch. It responds to the REAL
 * mouse (it sits above the cursor canvas), so no matter how corrupted the
 * cursor becomes the user can always disable inverted control and glitch FX.
 */

import { useExperience } from '@/lib/experience-context'

function Toggle({
  label,
  on,
  onClick,
}: {
  label: string
  on: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className="font-pixel"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        fontSize: '0.5rem',
        color: on ? 'var(--dp-green)' : 'var(--dp-green-dim)',
        background: 'rgba(4,7,10,0.7)',
        border: '1px solid var(--dp-line)',
        padding: '6px 8px',
        textTransform: 'uppercase',
        cursor: 'pointer',
      }}
    >
      <span
        aria-hidden
        style={{
          width: 10,
          height: 10,
          background: on ? 'var(--dp-green)' : 'transparent',
          border: '1px solid var(--dp-green-dim)',
          boxShadow: on ? '0 0 6px var(--dp-green)' : 'none',
        }}
      />
      {label} {on ? 'ON' : 'OFF'}
    </button>
  )
}

export function AccessibilityBar() {
  const { settings, updateSettings, reset, stage } = useExperience()
  if (stage === 'landing') return null
  return (
    <div
      style={{
        position: 'fixed',
        top: 12,
        right: 12,
        zIndex: 60,
        display: 'flex',
        gap: 8,
        flexWrap: 'wrap',
        justifyContent: 'flex-end',
        maxWidth: '60vw',
      }}
    >
      <Toggle
        label="INVERT FX"
        on={settings.allowInvert}
        onClick={() => updateSettings({ allowInvert: !settings.allowInvert })}
      />
      <Toggle
        label="GLITCH FX"
        on={settings.allowGlitch}
        onClick={() => updateSettings({ allowGlitch: !settings.allowGlitch })}
      />
      <button
        type="button"
        onClick={() => {
          if (
            typeof window !== 'undefined' &&
            window.confirm('Reset the whole experience?')
          ) {
            reset()
          }
        }}
        className="font-pixel"
        style={{
          fontSize: '0.5rem',
          color: 'var(--dp-red)',
          background: 'rgba(4,7,10,0.7)',
          border: '1px solid rgba(255,77,94,0.4)',
          padding: '6px 8px',
          textTransform: 'uppercase',
          cursor: 'pointer',
        }}
      >
        RESET
      </button>
    </div>
  )
}
