/**
 * Pixel-grid helpers: the 16x16 model, colour palette, starter templates,
 * deterministic corruption, and canvas / data-URL rendering.
 *
 * A "cursor" is a flat array of length GRID*GRID. Each cell is either '' for a
 * transparent pixel or a hex colour string.
 */

export const GRID = 16

/** Limited retro palette. First entry ('') means "erase / transparent". */
export const PALETTE = [
  '', // transparent (eraser color)
  '#0a0a0a', // outline black
  '#e6fff0', // bone white
  '#35ff7c', // phosphor green
  '#1f8f47', // deep green
  '#57f7ff', // cyan
  '#2b6cff', // blue
  '#ffb845', // amber
  '#ff8a3d', // orange
  '#ff4d5e', // red
  '#c04dff', // violet
  '#8a8f98', // grey
] as const

/** Colours the corruption engine bleeds into the design. */
const GLITCH_COLORS = ['#ff4d5e', '#57f7ff', '#c04dff']

// --- Template parsing -------------------------------------------------------

const CHAR_COLORS: Record<string, string> = {
  '.': '',
  X: '#0a0a0a', // outline
  W: '#e6fff0', // white fill
  G: '#35ff7c', // green
  C: '#57f7ff', // cyan
  R: '#ff4d5e', // red
}

function parse(rows: string[]): string[] {
  const out: string[] = new Array(GRID * GRID).fill('')
  for (let y = 0; y < GRID; y++) {
    const row = rows[y] ?? ''
    for (let x = 0; x < GRID; x++) {
      const ch = row[x] ?? '.'
      out[y * GRID + x] = CHAR_COLORS[ch] ?? ''
    }
  }
  return out
}

const ARROW = [
  'X...............',
  'XX..............',
  'XWX.............',
  'XWWX............',
  'XWWWX...........',
  'XWWWWX..........',
  'XWWWWWX.........',
  'XWWWWWWX........',
  'XWWWWWWWX.......',
  'XWWWWWWWWX......',
  'XWWWWWXXXXX.....',
  'XWWXWWX.........',
  'XWX.XWWX........',
  'XX..XWWX........',
  'X....XWWX.......',
  '.....XXXX.......',
]

const HAND = [
  '......XX........',
  '.....XWWX.......',
  '.....XWWX.......',
  '.....XWWX.......',
  '.....XWWXXX.....',
  '.....XWWWWWXX...',
  '..XX.XWWWWWWWX..',
  '.XWWXXWWWWWWWX..',
  '.XWWWWWWWWWWWX..',
  '.XWWWWWWWWWWWX..',
  '..XWWWWWWWWWX...',
  '..XWWWWWWWWWX...',
  '..XWWWWWWWWWX...',
  '..XWWWWWWWWWX...',
  '..XWWWWWWWWWX...',
  '..XXXXXXXXXXX...',
]

const CROSS = [
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
  '................',
  '................',
  'GGGGG..CC..GGGGG',
  'GGGGG..CC..GGGGG',
  '................',
  '................',
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
  '.......GG.......',
]

export type TemplateId = 'arrow' | 'hand' | 'cross' | 'custom'

export const TEMPLATES: Record<TemplateId, () => string[]> = {
  arrow: () => parse(ARROW),
  hand: () => parse(HAND),
  cross: () => parse(CROSS),
  custom: () => new Array(GRID * GRID).fill(''),
}

export function arrowTemplate(): string[] {
  return TEMPLATES.arrow()
}

// --- Deterministic RNG (mulberry32) -----------------------------------------

function mulberry32(seed: number) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/**
 * Produce a corrupted copy of a design. Deterministic for a given
 * (pixels, level, seed) so the "repair" target is stable across renders.
 * `level` 0..1 controls how many painted pixels get damaged.
 */
export function corrupt(pixels: string[], level: number, seed = 1337): string[] {
  const rng = mulberry32(seed)
  const out = [...pixels]
  const painted = pixels
    .map((c, i) => (c ? i : -1))
    .filter((i) => i >= 0)
  const damageCount = Math.round(painted.length * Math.min(1, level) * 0.7)

  // Shuffle painted indices deterministically, then damage the first N.
  const order = [...painted].sort(() => rng() - 0.5)
  for (let k = 0; k < damageCount; k++) {
    const idx = order[k]
    if (rng() < 0.6) {
      out[idx] = '' // dead pixel (missing)
    } else {
      out[idx] = GLITCH_COLORS[Math.floor(rng() * GLITCH_COLORS.length)]
    }
  }
  return out
}

/** Flip exactly one pixel — used for the very first, subtle glitch. */
export function nudgeOnePixel(pixels: string[], seed = 7): string[] {
  const rng = mulberry32(seed)
  const out = [...pixels]
  const painted = pixels.map((c, i) => (c ? i : -1)).filter((i) => i >= 0)
  if (painted.length === 0) return out
  const idx = painted[Math.floor(rng() * painted.length)]
  out[idx] = out[idx] === '#ff4d5e' ? '#57f7ff' : '#ff4d5e'
  return out
}

/** How many cells differ between two designs (used for repair completion). */
export function diffCount(a: string[], b: string[]): number {
  let n = 0
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) n++
  return n
}

// --- Rendering --------------------------------------------------------------

/** Draw a design onto a 2D context at a given cell size. */
export function drawPixels(
  ctx: CanvasRenderingContext2D,
  pixels: string[],
  cell: number,
  opts: { grid?: boolean; ox?: number; oy?: number } = {},
) {
  const { grid = false, ox = 0, oy = 0 } = opts
  ctx.imageSmoothingEnabled = false
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const c = pixels[y * GRID + x]
      const px = ox + x * cell
      const py = oy + y * cell
      if (c) {
        ctx.fillStyle = c
        ctx.fillRect(px, py, cell, cell)
      }
      if (grid) {
        ctx.strokeStyle = 'rgba(53,255,124,0.12)'
        ctx.lineWidth = 1
        ctx.strokeRect(px + 0.5, py + 0.5, cell, cell)
      }
    }
  }
}

/** Render a design to a standalone data URL (for a real CSS cursor preview). */
export function pixelsToDataURL(pixels: string[], scale = 2): string {
  if (typeof document === 'undefined') return ''
  const canvas = document.createElement('canvas')
  canvas.width = GRID * scale
  canvas.height = GRID * scale
  const ctx = canvas.getContext('2d')
  if (!ctx) return ''
  drawPixels(ctx, pixels, scale)
  return canvas.toDataURL('image/png')
}

/** True if the design has at least one painted pixel. */
export function hasPixels(pixels: string[]): boolean {
  return pixels.some((c) => c)
}
