'use client'

/**
 * Central state machine + persistence for the DEAD PIXEL experience.
 *
 * Everything the experience needs to be deterministic lives here:
 *  - the current `stage` (a linear, ordered state machine)
 *  - the working `pixels` grid and the pristine `savedPixels` design
 *  - the chosen `name`
 *  - the `corruption` level (0 = healthy, 1 = fully corrupted)
 *  - `settings` for accessibility (disable inverted control / glitch effects)
 *
 * State is mirrored to localStorage so a refresh keeps you in place.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import { GRID, arrowTemplate } from '@/lib/pixel-utils'

export const STAGES = [
  'landing',
  'init',
  'builder',
  'name',
  'test',
  'glitch',
  'personality',
  'invert',
  'drag',
  'independent',
  'escape',
  'repair',
  'reveal',
] as const

export type Stage = (typeof STAGES)[number]

export type Settings = {
  /** When false, inverted / autonomous control is neutralised (still completable). */
  allowInvert: boolean
  /** When false, glitch + flicker visuals are muted. */
  allowGlitch: boolean
}

export type ExperienceState = {
  stage: Stage
  /** Current working / displayed cursor. length === GRID*GRID, '' = transparent. */
  pixels: string[]
  /** The pristine design captured when the user pressed DONE in the builder. */
  savedPixels: string[]
  name: string
  corruption: number
  settings: Settings
}

const STORAGE_KEY = 'deadpixel:v1'

const defaultState: ExperienceState = {
  stage: 'landing',
  pixels: arrowTemplate(),
  savedPixels: arrowTemplate(),
  name: '',
  corruption: 0,
  settings: { allowInvert: true, allowGlitch: true },
}

type ExperienceContextValue = ExperienceState & {
  setStage: (stage: Stage) => void
  advance: () => void
  goTo: (stage: Stage) => void
  setPixels: (pixels: string[]) => void
  saveDesign: (pixels: string[]) => void
  setName: (name: string) => void
  setCorruption: (value: number) => void
  updateSettings: (patch: Partial<Settings>) => void
  reset: () => void
  /** Live pointer positions shared with the cursor engine (imperative, no re-render). */
  pointer: React.RefObject<PointerShared>
}

export type PointerShared = {
  /** Raw mouse position. */
  realX: number
  realY: number
  /** Where the rendered cursor actually is (may differ under corruption). */
  virtualX: number
  virtualY: number
}

const ExperienceContext = createContext<ExperienceContextValue | null>(null)

function loadState(): ExperienceState {
  if (typeof window === 'undefined') return defaultState
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultState
    const parsed = JSON.parse(raw) as Partial<ExperienceState>
    return {
      ...defaultState,
      ...parsed,
      settings: { ...defaultState.settings, ...parsed.settings },
      pixels:
        Array.isArray(parsed.pixels) && parsed.pixels.length === GRID * GRID
          ? parsed.pixels
          : defaultState.pixels,
      savedPixels:
        Array.isArray(parsed.savedPixels) &&
        parsed.savedPixels.length === GRID * GRID
          ? parsed.savedPixels
          : defaultState.savedPixels,
    }
  } catch {
    return defaultState
  }
}

export function ExperienceProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<ExperienceState>(defaultState)
  const [hydrated, setHydrated] = useState(false)

  const pointer = useRef<PointerShared>({
    realX: 0,
    realY: 0,
    virtualX: 0,
    virtualY: 0,
  })

  // Hydrate from storage after mount to avoid SSR mismatch.
  useEffect(() => {
    setState(loadState())
    setHydrated(true)
  }, [])

  // Persist on every change once hydrated.
  useEffect(() => {
    if (!hydrated) return
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      /* ignore quota / privacy errors */
    }
  }, [state, hydrated])

  const setStage = useCallback((stage: Stage) => {
    setState((s) => ({ ...s, stage }))
  }, [])

  const goTo = setStage

  const advance = useCallback(() => {
    setState((s) => {
      const i = STAGES.indexOf(s.stage)
      const next = STAGES[Math.min(i + 1, STAGES.length - 1)]
      return { ...s, stage: next }
    })
  }, [])

  const setPixels = useCallback((pixels: string[]) => {
    setState((s) => ({ ...s, pixels }))
  }, [])

  const saveDesign = useCallback((pixels: string[]) => {
    setState((s) => ({ ...s, pixels: [...pixels], savedPixels: [...pixels] }))
  }, [])

  const setName = useCallback((name: string) => {
    setState((s) => ({ ...s, name }))
  }, [])

  const setCorruption = useCallback((value: number) => {
    setState((s) => ({ ...s, corruption: Math.max(0, Math.min(1, value)) }))
  }, [])

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } }))
  }, [])

  const reset = useCallback(() => {
    setState({ ...defaultState, pixels: arrowTemplate(), savedPixels: arrowTemplate() })
    try {
      window.localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* ignore */
    }
  }, [])

  const value = useMemo<ExperienceContextValue>(
    () => ({
      ...state,
      setStage,
      advance,
      goTo,
      setPixels,
      saveDesign,
      setName,
      setCorruption,
      updateSettings,
      reset,
      pointer,
    }),
    [
      state,
      setStage,
      advance,
      goTo,
      setPixels,
      saveDesign,
      setName,
      setCorruption,
      updateSettings,
      reset,
    ],
  )

  return (
    <ExperienceContext.Provider value={value}>
      {children}
    </ExperienceContext.Provider>
  )
}

export function useExperience() {
  const ctx = useContext(ExperienceContext)
  if (!ctx) {
    throw new Error('useExperience must be used within an ExperienceProvider')
  }
  return ctx
}
